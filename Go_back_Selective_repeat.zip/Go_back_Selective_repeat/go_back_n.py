# go_back.py

def go_back_n_simulation():
    print("\n--- Go-Back-N ARQ Simulation ---")
    
    n = int(input("Enter window size: "))
    frames = input("Enter frames to send (space separated numbers): ").split()
    frames = [int(f) for f in frames]
    
    ack = -1  # last acknowledged frame
    i = 0
    while i < len(frames):
        print(f"Sending frames {frames[i:i+n]}")
        # Simulate a lost frame
        lost_frame = int(input("Enter lost frame (-1 if none lost): "))
        if lost_frame in frames[i:i+n]:
            print(f"Frame {lost_frame} lost. Resending from frame {lost_frame}")
            i = frames.index(lost_frame)
        else:
            ack = i + n - 1
            print(f"All frames acknowledged up to frame {ack}")
            i += n
