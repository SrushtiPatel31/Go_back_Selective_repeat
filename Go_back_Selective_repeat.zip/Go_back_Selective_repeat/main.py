# main.py

from go_back_n import go_back_n_simulation
from selective_repeat import selective_repeat_simulation

def main():
    while True:
        print("\n--- ARQ Protocol Simulator ---")
        print("1. Go-Back-N")
        print("2. Selective Repeat")
        print("3. Exit")
        choice = input("Enter your choice: ")

        if choice == '1':
            go_back_n_simulation()
        elif choice == '2':
            selective_repeat_simulation()
        elif choice == '3':
            print("Exiting program.")
            break
        else:
            print("Invalid choice. Please enter 1, 2, or 3.")

if __name__ == "__main__":
    main()
