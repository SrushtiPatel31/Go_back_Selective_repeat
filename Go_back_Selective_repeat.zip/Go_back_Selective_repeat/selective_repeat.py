# selective.py

def selective_repeat_simulation():
    print("\n--- Selective Repeat ARQ Simulation ---")
    
    n = int(input("Enter window size: "))
    frames = input("Enter frames to send (space separated numbers): ").split()
    frames = [int(f) for f in frames]
    
    acked_frames = set()
    
    i = 0
    while i < len(frames):
        print(f"Sending frames {frames[i:i+n]}")
        # Simulate lost frames
        lost_frames_input = input("Enter lost frames (space separated, -1 if none lost): ")
        lost_frames = [int(f) for f in lost_frames_input.split()] if lost_frames_input != "-1" else []

        for f in frames[i:i+n]:
            if f not in lost_frames:
                acked_frames.add(f)
        
        print(f"Acknowledged frames: {sorted(acked_frames)}")
        
        # Move the window
        while i < len(frames) and frames[i] in acked_frames:
            i += 1
